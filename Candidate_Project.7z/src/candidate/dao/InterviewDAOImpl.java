package candidate.dao;

import java.util.List;

import org.hibernate.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import candidate.entities.*;

@Repository("InterviewDAO")
public class InterviewDAOImpl implements InterviewDAO{

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public List<Interview> showAll() {
		
		return sessionFactory.getCurrentSession().createCriteria(Interview.class).list();
	}

	@Override
	public void Add(Interview interview) {
//		Interview interview2 =this.searchbyEmail(interview.getCandidate().getEmail());
//		interview.getCandidate().getFullName();
//		System.out.println(interview.getCandidate().getFullName());
//		if(interview==null)
//		sessionFactory.getCurrentSession().save(interview);
//		else return;
		sessionFactory.getCurrentSession().persist(interview);
	}

	private Interview searchbyEmail(String email) {
		 Interview interview;
		try{  interview = (Interview) sessionFactory.getCurrentSession().createQuery("from candidate where Email=:email")
				 .setParameter("email", email).list().get(0);
		}
		catch(Exception e){return null;}
		 return interview;
	}

}
