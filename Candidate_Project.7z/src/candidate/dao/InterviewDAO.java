package candidate.dao;

import candidate.entities.*;
import java.util.*;

public interface InterviewDAO {

	public List<Interview> showAll();
	public void Add(Interview interview);
}
