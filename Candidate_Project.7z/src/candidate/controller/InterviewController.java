package candidate.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import candidate.entities.*;
import candidate.service.InterviewService;

@Controller
@RequestMapping(value = "interview**")
public class InterviewController {

	@Autowired
	private InterviewService interviewService;

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public String index(ModelMap modelMap) {
		modelMap.put("interviews", interviewService.showAll());

		return "interview/listForm";
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String add(ModelMap modelMap) {

		modelMap.put("interview", new Interview());
		return "interview/addForm";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String add(@ModelAttribute("interview") Interview interview, ModelMap modelMap) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String name = authentication.getName();

		interviewService.Add(interview);
		return "redirect:/interview/list.html";
	}
}
