package candidate.service;

import java.util.*;
import candidate.entities.*;

public interface InterviewService {
	public List<Interview> showAll();
	public void Add(Interview interview);
}
