package candidate.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import candidate.dao.InterviewDAO;
import candidate.entities.*;

@Service("interviewService")
@Transactional
public class InterviewServiceImpl implements InterviewService{
	
	@Autowired
	private InterviewDAO interviewDAO;
	
	@Override
	public List<Interview> showAll() {
		
		return interviewDAO.showAll();
	}

	@Override
	public void Add(Interview interview) {
		interviewDAO.Add(interview);
		
	}

}
